# Atividade-3-DW

Para aceder ao conteúdo o link será: 
http://localhost:8050/

Para aceder ao contéudo de um site específico os links serão: 
http://localhost:8050/boxoffice/Variety
http://localhost:8050/boxoffice/Hollywood%20Reporter
http://localhost:8050/boxoffice/Deadline
http://localhost:8050/boxoffice/The%20Numbers
http://localhost:8050/boxoffice/Box%20Office%20Pro
